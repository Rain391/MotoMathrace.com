<script type="module">const user = await getUserInfo() </script> 
<script src="https://replit.com/public/js/repl-auth-v2.js"></script>